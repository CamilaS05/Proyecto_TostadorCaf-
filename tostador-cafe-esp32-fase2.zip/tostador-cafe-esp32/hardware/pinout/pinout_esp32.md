# Pinout inicial ESP32

| Subsistema | Señal | GPIO | Nota |
|---|---:|---:|---|
| SPI compartido | SCK | 18 | MAX6675 y MicroSD |
| SPI compartido | MISO | 19 | MAX6675 SO y MicroSD MISO |
| SPI compartido | MOSI | 23 | Solo MicroSD; MAX6675 no usa MOSI |
| MicroSD | CS | 5 | Chip select SD |
| MAX6675 | CS | 15 | Chip select termocupla |
| Calentador | SSR | 25 | Salida digital hacia SSR-40DA |
| Motor | PWM | 26 | MOSFET LR7843 |
| Ventilador | PWM | 27 | MOSFET |
| I2C | SDA | 21 | LCD/SHT31/RTC opcional |
| I2C | SCL | 22 | LCD/SHT31/RTC opcional |
| Botón START | Entrada | 32 | Pendiente pull-up/pull-down |
| Botón STOP | Entrada | 33 | Pendiente pull-up/pull-down |
| Botón PAUSE | Entrada | 34 | Solo entrada, requiere resistencia externa |
