#include "fan_driver.h"
#include "gpio_map.h"
#include "driver/ledc.h"
#include <algorithm>

static constexpr ledc_channel_t FAN_CH = LEDC_CHANNEL_1;
static constexpr ledc_timer_t FAN_TIMER = LEDC_TIMER_1;

esp_err_t fan_init(void) {
    ledc_timer_config_t timer = {};
    timer.speed_mode = LEDC_LOW_SPEED_MODE;
    timer.timer_num = FAN_TIMER;
    timer.duty_resolution = LEDC_TIMER_10_BIT;
    timer.freq_hz = 25000;
    timer.clk_cfg = LEDC_AUTO_CLK;
    ESP_ERROR_CHECK(ledc_timer_config(&timer));

    ledc_channel_config_t ch = {};
    ch.gpio_num = PIN_FAN_PWM;
    ch.speed_mode = LEDC_LOW_SPEED_MODE;
    ch.channel = FAN_CH;
    ch.intr_type = LEDC_INTR_DISABLE;
    ch.timer_sel = FAN_TIMER;
    ch.duty = 0;
    ch.hpoint = 0;
    return ledc_channel_config(&ch);
}
void fan_set_duty(uint8_t duty_percent) {
    if (duty_percent > 100) duty_percent = 100;
    uint32_t duty = (1023 * duty_percent) / 100;
    ledc_set_duty(LEDC_LOW_SPEED_MODE, FAN_CH, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, FAN_CH);
}
void fan_stop(void) { fan_set_duty(0); }
