#include "max6675_driver.h"
#include "gpio_map.h"
#include "app_events.h"
#include "driver/spi_master.h"
#include "esp_log.h"
#include <cstring>

static const char *TAG = "MAX6675";
static spi_device_handle_t s_max6675 = nullptr;
static bool s_spi_ready = false;

esp_err_t max6675_init(void) {
    if (!s_spi_ready) {
        spi_bus_config_t buscfg = {};
        buscfg.miso_io_num = PIN_SPI_MISO;
        buscfg.mosi_io_num = PIN_SPI_MOSI; // La SD sí usa MOSI. El MAX6675 lo ignora.
        buscfg.sclk_io_num = PIN_SPI_SCK;
        buscfg.quadwp_io_num = -1;
        buscfg.quadhd_io_num = -1;
        buscfg.max_transfer_sz = 512;

        esp_err_t err = spi_bus_initialize(SPI2_HOST, &buscfg, SPI_DMA_CH_AUTO);
        if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
            ESP_LOGE(TAG, "No se pudo inicializar SPI: %s", esp_err_to_name(err));
            return err;
        }
        s_spi_ready = true;
    }

    spi_device_interface_config_t devcfg = {};
    devcfg.clock_speed_hz = 1 * 1000 * 1000;
    devcfg.mode = 0;
    devcfg.spics_io_num = PIN_MAX6675_CS;
    devcfg.queue_size = 1;

    esp_err_t err = spi_bus_add_device(SPI2_HOST, &devcfg, &s_max6675);
    if (err == ESP_ERR_INVALID_STATE) return ESP_OK;
    return err;
}

esp_err_t max6675_read_celsius(float *temperature_c, bool *sensor_ok) {
    if (!temperature_c || !sensor_ok || !s_max6675) return ESP_ERR_INVALID_ARG;

    uint16_t raw_data = 0;
    spi_transaction_t t = {};
    t.length = 16;
    t.rx_buffer = &raw_data;

    if (g_spi_mutex) xSemaphoreTake(g_spi_mutex, portMAX_DELAY);
    esp_err_t err = spi_device_transmit(s_max6675, &t);
    if (g_spi_mutex) xSemaphoreGive(g_spi_mutex);

    if (err != ESP_OK) {
        *sensor_ok = false;
        return err;
    }

    raw_data = __builtin_bswap16(raw_data);
    if (raw_data & 0x04) {
        *sensor_ok = false;
        *temperature_c = -1.0f;
        return ESP_OK;
    }

    *sensor_ok = true;
    *temperature_c = static_cast<float>(raw_data >> 3) * 0.25f;
    return ESP_OK;
}
