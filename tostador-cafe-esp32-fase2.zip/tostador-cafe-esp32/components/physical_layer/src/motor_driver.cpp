#include "motor_driver.h"
#include "gpio_map.h"
#include "driver/ledc.h"
#include <algorithm>

static constexpr ledc_channel_t MOTOR_CH = LEDC_CHANNEL_0;
static constexpr ledc_timer_t MOTOR_TIMER = LEDC_TIMER_0;

esp_err_t motor_init(void) {
    ledc_timer_config_t timer = {};
    timer.speed_mode = LEDC_LOW_SPEED_MODE;
    timer.timer_num = MOTOR_TIMER;
    timer.duty_resolution = LEDC_TIMER_10_BIT;
    timer.freq_hz = 5000;
    timer.clk_cfg = LEDC_AUTO_CLK;
    ESP_ERROR_CHECK(ledc_timer_config(&timer));

    ledc_channel_config_t ch = {};
    ch.gpio_num = PIN_MOTOR_PWM;
    ch.speed_mode = LEDC_LOW_SPEED_MODE;
    ch.channel = MOTOR_CH;
    ch.intr_type = LEDC_INTR_DISABLE;
    ch.timer_sel = MOTOR_TIMER;
    ch.duty = 0;
    ch.hpoint = 0;
    return ledc_channel_config(&ch);
}
void motor_set_duty(uint8_t duty_percent) {
    duty_percent = std::min<uint8_t>(duty_percent, 100);
    uint32_t duty = (1023 * duty_percent) / 100;
    ledc_set_duty(LEDC_LOW_SPEED_MODE, MOTOR_CH, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, MOTOR_CH);
}
void motor_stop(void) { motor_set_duty(0); }
