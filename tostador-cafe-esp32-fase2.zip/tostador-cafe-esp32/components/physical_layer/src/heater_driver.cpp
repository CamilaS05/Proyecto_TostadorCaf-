#include "heater_driver.h"
#include "gpio_map.h"
#include "driver/gpio.h"

esp_err_t heater_init(void) {
    gpio_reset_pin(PIN_HEATER_SSR);
    gpio_set_direction(PIN_HEATER_SSR, GPIO_MODE_OUTPUT);
    gpio_set_level(PIN_HEATER_SSR, 0);
    return ESP_OK;
}
void heater_set(bool enable) { gpio_set_level(PIN_HEATER_SSR, enable ? 1 : 0); }
void heater_off(void) { heater_set(false); }
