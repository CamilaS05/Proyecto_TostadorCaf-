/**
 * @file max6675_driver.h
 * @brief Driver SPI para módulo MAX6675 con termocupla tipo K.
 */
#pragma once
#include "esp_err.h"

/** @brief Inicializa el bus SPI y registra el dispositivo MAX6675. */
esp_err_t max6675_init(void);

/**
 * @brief Lee la temperatura de la termocupla.
 * @param[out] temperature_c Temperatura en grados Celsius.
 * @param[out] sensor_ok true si la termocupla está conectada.
 * @return ESP_OK si se pudo hacer la transacción SPI.
 */
esp_err_t max6675_read_celsius(float *temperature_c, bool *sensor_ok);
