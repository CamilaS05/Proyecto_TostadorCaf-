/**
 * @file heater_driver.h
 * @brief Control seguro del SSR que conmuta la resistencia calefactora.
 */
#pragma once
#include "esp_err.h"

/** @brief Inicializa el GPIO del SSR en apagado. */
esp_err_t heater_init(void);
/** @brief Enciende o apaga directamente el SSR. */
void heater_set(bool enable);
/** @brief Apagado inmediato del calentador. */
void heater_off(void);
