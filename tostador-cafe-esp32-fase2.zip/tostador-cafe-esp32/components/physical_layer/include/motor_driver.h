/**
 * @file motor_driver.h
 * @brief Driver PWM para motorreductor del tambor.
 */
#pragma once
#include "esp_err.h"
/** @brief Inicializa PWM del motor. */
esp_err_t motor_init(void);
/** @brief Define ciclo útil del motor de 0 a 100 %. */
void motor_set_duty(uint8_t duty_percent);
/** @brief Detiene el motor. */
void motor_stop(void);
