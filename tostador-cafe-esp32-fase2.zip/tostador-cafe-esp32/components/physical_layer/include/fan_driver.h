/**
 * @file fan_driver.h
 * @brief Driver PWM para ventilador de enfriamiento.
 */
#pragma once
#include "esp_err.h"
/** @brief Inicializa PWM del ventilador. */
esp_err_t fan_init(void);
/** @brief Define ciclo útil del ventilador de 0 a 100 %. */
void fan_set_duty(uint8_t duty_percent);
/** @brief Detiene ventilador. */
void fan_stop(void);
