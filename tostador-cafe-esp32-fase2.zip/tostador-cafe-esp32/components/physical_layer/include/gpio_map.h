/**
 * @file gpio_map.h
 * @brief Mapa centralizado de pines del ESP32.
 * @note Ajustar estos pines si el esquemático en EasyEDA cambia.
 */
#pragma once
#include "driver/gpio.h"

// SPI compartido: MicroSD y MAX6675 pueden compartir SCK/MISO/MOSI con CS independientes.
static constexpr gpio_num_t PIN_SPI_MISO = GPIO_NUM_19;
static constexpr gpio_num_t PIN_SPI_MOSI = GPIO_NUM_23;
static constexpr gpio_num_t PIN_SPI_SCK  = GPIO_NUM_18;
static constexpr gpio_num_t PIN_SD_CS    = GPIO_NUM_5;
static constexpr gpio_num_t PIN_MAX6675_CS = GPIO_NUM_15;

// Actuadores.
static constexpr gpio_num_t PIN_HEATER_SSR = GPIO_NUM_25;
static constexpr gpio_num_t PIN_MOTOR_PWM  = GPIO_NUM_26;
static constexpr gpio_num_t PIN_FAN_PWM    = GPIO_NUM_27;

// Entradas de interacción provisional.
static constexpr gpio_num_t PIN_BTN_START = GPIO_NUM_32;
static constexpr gpio_num_t PIN_BTN_STOP  = GPIO_NUM_33;
static constexpr gpio_num_t PIN_BTN_PAUSE = GPIO_NUM_34;

// I2C opcional para LCD/SHT31/RTC.
static constexpr gpio_num_t PIN_I2C_SDA = GPIO_NUM_21;
static constexpr gpio_num_t PIN_I2C_SCL = GPIO_NUM_22;
