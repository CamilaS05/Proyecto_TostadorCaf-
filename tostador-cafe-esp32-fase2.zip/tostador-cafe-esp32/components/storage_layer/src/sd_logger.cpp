#include "sd_logger.h"
#include "gpio_map.h"
#include "app_events.h"
#include "esp_log.h"
#include "esp_vfs_fat.h"
#include "sdmmc_cmd.h"
#include <sys/stat.h>
#include <cstdio>

static const char *TAG = "SD_LOGGER";
static bool s_sd_ready = false;
static const char *LOG_DIR = "/sdcard/logs";
static const char *DATA_FILE = "/sdcard/logs/tostion.csv";
static const char *ALARM_FILE = "/sdcard/logs/alarmas.csv";

esp_err_t sd_logger_init(void) {
    esp_vfs_fat_sdmmc_mount_config_t mount_config = {};
    mount_config.format_if_mount_failed = false;
    mount_config.max_files = 5;
    mount_config.allocation_unit_size = 16 * 1024;

    sdmmc_card_t *card = nullptr;
    sdspi_device_config_t slot_config = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot_config.gpio_cs = PIN_SD_CS;
    slot_config.host_id = SPI2_HOST;

    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.slot = SPI2_HOST;

    if (g_spi_mutex) xSemaphoreTake(g_spi_mutex, portMAX_DELAY);
    esp_err_t err = esp_vfs_fat_sdspi_mount("/sdcard", &host, &slot_config, &mount_config, &card);
    if (g_spi_mutex) xSemaphoreGive(g_spi_mutex);

    if (err != ESP_OK) {
        ESP_LOGW(TAG, "No se pudo montar SD: %s", esp_err_to_name(err));
        s_sd_ready = false;
        return err;
    }
    s_sd_ready = true;
    mkdir(LOG_DIR, 0755);
    ESP_LOGI(TAG, "MicroSD montada correctamente");
    return ESP_OK;
}

void sd_logger_write_header(void) {
    if (!s_sd_ready) return;
    FILE *f = fopen(DATA_FILE, "a+");
    if (f) {
        fseek(f, 0, SEEK_END);
        if (ftell(f) == 0) fprintf(f, "timestamp_ms,state,temp_c,thermocouple_ok,ambient_c,humidity_percent,mass_g\n");
        fclose(f);
    }
    f = fopen(ALARM_FILE, "a+");
    if (f) {
        fseek(f, 0, SEEK_END);
        if (ftell(f) == 0) fprintf(f, "timestamp_ms,code,temp_c\n");
        fclose(f);
    }
}

void sd_logger_write_sample(const SensorSample &sample, ProcessState state) {
    printf("DATA,%llu,%u,%.2f,%d\n", sample.timestamp_ms, static_cast<unsigned>(state), sample.temperature_c, sample.thermocouple_ok);
    if (!s_sd_ready) return;
    FILE *f = fopen(DATA_FILE, "a");
    if (!f) return;
    fprintf(f, "%llu,%u,%.2f,%d,%.2f,%.2f,%.2f\n",
            sample.timestamp_ms,
            static_cast<unsigned>(state),
            sample.temperature_c,
            sample.thermocouple_ok ? 1 : 0,
            sample.ambient_c,
            sample.humidity_percent,
            sample.mass_g);
    fclose(f);
}

void sd_logger_write_alarm(const AlarmMessage &alarm) {
    printf("ALARM,%llu,%u,%.2f\n", alarm.timestamp_ms, static_cast<unsigned>(alarm.code), alarm.temperature_c);
    if (!s_sd_ready) return;
    FILE *f = fopen(ALARM_FILE, "a");
    if (!f) return;
    fprintf(f, "%llu,%u,%.2f\n", alarm.timestamp_ms, static_cast<unsigned>(alarm.code), alarm.temperature_c);
    fclose(f);
}
