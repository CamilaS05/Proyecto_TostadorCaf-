/**
 * @file sd_logger.h
 * @brief Registro de datos en MicroSD y salida serial.
 */
#pragma once
#include "esp_err.h"
#include "app_types.h"
/** @brief Monta la MicroSD por SPI. */
esp_err_t sd_logger_init(void);
/** @brief Escribe encabezado CSV si el archivo está vacío. */
void sd_logger_write_header(void);
/** @brief Registra una muestra de sensores en CSV. */
void sd_logger_write_sample(const SensorSample &sample, ProcessState state);
/** @brief Registra una alarma del sistema. */
void sd_logger_write_alarm(const AlarmMessage &alarm);
