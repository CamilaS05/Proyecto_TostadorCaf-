#include "power_manager.h"
#include "esp_log.h"
#include "esp_pm.h"

static const char *TAG = "POWER";

esp_err_t power_manager_init(void) {
#if CONFIG_PM_ENABLE
    esp_pm_config_t pm_config = {};
    pm_config.max_freq_mhz = 240;
    pm_config.min_freq_mhz = 80;
    pm_config.light_sleep_enable = false; // En tostión se evita sleep para no afectar control en tiempo real.
    return esp_pm_configure(&pm_config);
#else
    ESP_LOGW(TAG, "Power management no habilitado en menuconfig. Se documenta gestion energetica basica.");
    return ESP_OK;
#endif
}

void power_manager_apply_idle_mode(void) {
    // Punto de extensión: reducir frecuencia, apagar LCD o entrar en light sleep cuando el tostador esté FINISHED.
}
