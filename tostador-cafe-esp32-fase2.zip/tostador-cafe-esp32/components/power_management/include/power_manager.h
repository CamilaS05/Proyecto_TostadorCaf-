/**
 * @file power_manager.h
 * @brief Gestión energética básica del nodo ESP32.
 */
#pragma once
#include "esp_err.h"
/** @brief Inicializa políticas de energía compatibles con FreeRTOS. */
esp_err_t power_manager_init(void);
/** @brief Aplica modo ahorro cuando el proceso está inactivo. */
void power_manager_apply_idle_mode(void);
