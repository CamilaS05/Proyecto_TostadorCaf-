/**
 * @file app_context.h
 * @brief Contexto global protegido del proceso de tostión.
 */
#pragma once
#include "app_types.h"

/** @brief Inicializa el contexto global. */
void app_context_init(void);
/** @brief Retorna el estado actual del proceso. */
ProcessState app_get_state(void);
/** @brief Cambia el estado del proceso de forma protegida. */
void app_set_state(ProcessState state);
/** @brief Retorna el perfil activo de tostión. */
RoastProfile app_get_profile(void);
/** @brief Cambia el perfil activo de tostión. */
void app_set_profile(const RoastProfile &profile);
/** @brief Solicita apagado seguro por emergencia. */
void app_request_safe_shutdown(SafetyCode code);
/** @brief Retorna la última alarma. */
SafetyCode app_get_last_alarm(void);
