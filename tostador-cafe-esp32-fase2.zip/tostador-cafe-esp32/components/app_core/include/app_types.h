/**
 * @file app_types.h
 * @brief Tipos compartidos del tostador de café.
 */
#pragma once
#include <stdint.h>

/** @brief Estados generales del proceso de tostión. */
enum class ProcessState : uint8_t {
    CONFIGURATION = 0,
    VALIDATION,
    READY,
    ROASTING,
    PAUSED_SAFE,
    ANOMALY,
    COOLING,
    FINISHED,
    ERROR
};

/** @brief Comandos generados desde la capa de interacción. */
enum class UserCommand : uint8_t {
    NONE = 0,
    CONFIGURE,
    START,
    PAUSE,
    RESUME,
    STOP,
    FINISH,
    EMERGENCY_STOP
};

/** @brief Códigos de seguridad y fallos detectables. */
enum class SafetyCode : uint8_t {
    OK = 0,
    SENSOR_DISCONNECTED,
    TEMP_OUT_OF_RANGE,
    TEMP_RISE_TOO_FAST,
    HEATER_STUCK_ON,
    MOTOR_FAULT,
    FAN_FAULT,
    EMERGENCY_STOP,
    POWER_FAULT,
    SD_FAULT
};

/** @brief Perfil básico de tostión. */
typedef struct {
    float target_temp_c;        ///< Temperatura objetivo del proceso.
    float max_temp_c;           ///< Temperatura máxima permitida.
    float min_valid_temp_c;     ///< Temperatura mínima físicamente válida.
    uint32_t roast_time_s;      ///< Tiempo de tostión en segundos.
    uint32_t cooling_time_s;    ///< Tiempo mínimo de enfriamiento.
    uint8_t motor_duty_percent; ///< PWM del motor en porcentaje.
    uint8_t fan_duty_percent;   ///< PWM del ventilador en porcentaje.
} RoastProfile;

/** @brief Lectura consolidada de sensores. */
typedef struct {
    uint64_t timestamp_ms;      ///< Tiempo del sistema en milisegundos.
    float temperature_c;        ///< Temperatura medida por termocupla.
    bool thermocouple_ok;       ///< Estado del MAX6675: true si la termocupla está conectada.
    float ambient_c;            ///< Temperatura ambiente opcional.
    float humidity_percent;     ///< Humedad relativa opcional.
    float mass_g;               ///< Masa opcional medida por HX711.
} SensorSample;

/** @brief Orden de control hacia actuadores. */
typedef struct {
    bool heater_enable;         ///< Habilitación del calentador.
    uint8_t heater_power_percent; ///< Potencia por control temporal del SSR.
    uint8_t motor_duty_percent; ///< PWM del motor.
    uint8_t fan_duty_percent;   ///< PWM del ventilador.
} ControlOutput;

/** @brief Mensaje de alarma entre servicios. */
typedef struct {
    SafetyCode code;            ///< Código de falla.
    uint64_t timestamp_ms;      ///< Instante de detección.
    float temperature_c;        ///< Temperatura asociada a la alarma.
} AlarmMessage;
