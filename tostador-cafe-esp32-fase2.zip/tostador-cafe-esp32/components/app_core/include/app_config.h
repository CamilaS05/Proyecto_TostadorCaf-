/**
 * @file app_config.h
 * @brief Parámetros de configuración por defecto del tostador.
 */
#pragma once
#include "app_types.h"

static constexpr RoastProfile DEFAULT_PROFILE = {
    .target_temp_c = 205.0f,
    .max_temp_c = 240.0f,
    .min_valid_temp_c = 0.0f,
    .roast_time_s = 8 * 60,
    .cooling_time_s = 2 * 60,
    .motor_duty_percent = 75,
    .fan_duty_percent = 80
};

static constexpr uint32_t MONITORING_PERIOD_MS = 1000;
static constexpr uint32_t CONTROL_PERIOD_MS = 500;
static constexpr uint32_t SAFETY_PERIOD_MS = 200;
static constexpr uint32_t LOGGING_QUEUE_TIMEOUT_MS = 100;
static constexpr float MAX_TEMP_RISE_C_PER_S = 8.0f;
static constexpr float COOLING_SAFE_TEMP_C = 60.0f;
