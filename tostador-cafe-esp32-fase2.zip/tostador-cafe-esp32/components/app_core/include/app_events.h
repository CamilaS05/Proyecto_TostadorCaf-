/**
 * @file app_events.h
 * @brief Colas y sincronización FreeRTOS compartidas.
 */
#pragma once
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "app_types.h"

extern QueueHandle_t g_sensor_queue;
extern QueueHandle_t g_command_queue;
extern QueueHandle_t g_log_queue;
extern QueueHandle_t g_alarm_queue;
extern SemaphoreHandle_t g_state_mutex;
extern SemaphoreHandle_t g_spi_mutex;

/** @brief Inicializa colas y semáforos globales. */
bool app_events_init(void);
