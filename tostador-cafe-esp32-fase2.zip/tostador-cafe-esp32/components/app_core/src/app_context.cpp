#include "app_context.h"
#include "app_events.h"
#include "app_config.h"

static ProcessState s_state = ProcessState::CONFIGURATION;
static RoastProfile s_profile = DEFAULT_PROFILE;
static SafetyCode s_last_alarm = SafetyCode::OK;

void app_context_init(void) {
    s_state = ProcessState::CONFIGURATION;
    s_profile = DEFAULT_PROFILE;
    s_last_alarm = SafetyCode::OK;
}

ProcessState app_get_state(void) {
    ProcessState state;
    xSemaphoreTake(g_state_mutex, portMAX_DELAY);
    state = s_state;
    xSemaphoreGive(g_state_mutex);
    return state;
}

void app_set_state(ProcessState state) {
    xSemaphoreTake(g_state_mutex, portMAX_DELAY);
    s_state = state;
    xSemaphoreGive(g_state_mutex);
}

RoastProfile app_get_profile(void) {
    RoastProfile profile;
    xSemaphoreTake(g_state_mutex, portMAX_DELAY);
    profile = s_profile;
    xSemaphoreGive(g_state_mutex);
    return profile;
}

void app_set_profile(const RoastProfile &profile) {
    xSemaphoreTake(g_state_mutex, portMAX_DELAY);
    s_profile = profile;
    xSemaphoreGive(g_state_mutex);
}

void app_request_safe_shutdown(SafetyCode code) {
    xSemaphoreTake(g_state_mutex, portMAX_DELAY);
    s_last_alarm = code;
    s_state = ProcessState::ANOMALY;
    xSemaphoreGive(g_state_mutex);
}

SafetyCode app_get_last_alarm(void) {
    SafetyCode code;
    xSemaphoreTake(g_state_mutex, portMAX_DELAY);
    code = s_last_alarm;
    xSemaphoreGive(g_state_mutex);
    return code;
}
