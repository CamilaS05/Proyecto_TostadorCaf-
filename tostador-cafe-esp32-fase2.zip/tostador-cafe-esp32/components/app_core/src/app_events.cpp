#include "app_events.h"

QueueHandle_t g_sensor_queue = nullptr;
QueueHandle_t g_command_queue = nullptr;
QueueHandle_t g_log_queue = nullptr;
QueueHandle_t g_alarm_queue = nullptr;
SemaphoreHandle_t g_state_mutex = nullptr;
SemaphoreHandle_t g_spi_mutex = nullptr;

bool app_events_init(void) {
    g_sensor_queue = xQueueCreate(8, sizeof(SensorSample));
    g_command_queue = xQueueCreate(8, sizeof(UserCommand));
    g_log_queue = xQueueCreate(16, sizeof(SensorSample));
    g_alarm_queue = xQueueCreate(8, sizeof(AlarmMessage));
    g_state_mutex = xSemaphoreCreateMutex();
    g_spi_mutex = xSemaphoreCreateMutex();
    return g_sensor_queue && g_command_queue && g_log_queue && g_alarm_queue && g_state_mutex && g_spi_mutex;
}
