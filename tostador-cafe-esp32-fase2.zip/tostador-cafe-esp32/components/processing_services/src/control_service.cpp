#include "control_service.h"
#include "app_config.h"
#include "app_context.h"
#include "app_events.h"
#include "heater_driver.h"
#include "motor_driver.h"
#include "fan_driver.h"
#include "esp_log.h"
#include "esp_check.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "CONTROL";
static uint32_t s_control_tick = 0;

static void apply_safe_outputs(void) {
    heater_off();
    motor_stop();
    fan_set_duty(100);
}

static void apply_control(const SensorSample &sample) {
    RoastProfile profile = app_get_profile();
    ProcessState state = app_get_state();

    if (state == ProcessState::ANOMALY || state == ProcessState::ERROR) {
        apply_safe_outputs();
        return;
    }

    if (state == ProcessState::PAUSED_SAFE) {
        heater_off();
        motor_set_duty(profile.motor_duty_percent); // mantiene agitación para no quemar granos.
        fan_set_duty(40);
        return;
    }

    if (state == ProcessState::COOLING) {
        heater_off();
        motor_set_duty(profile.motor_duty_percent);
        fan_set_duty(100);
        return;
    }

    if (state != ProcessState::ROASTING) {
        heater_off();
        motor_stop();
        fan_stop();
        return;
    }

    // Control simple tipo ON/OFF con histéresis. Es robusto para maqueta inicial con SSR.
    constexpr float hysteresis_c = 3.0f;
    bool heater = sample.temperature_c < (profile.target_temp_c - hysteresis_c);
    if (sample.temperature_c >= profile.target_temp_c) heater = false;

    // Ventana temporal para no conmutar demasiado rápido el SSR.
    s_control_tick = (s_control_tick + CONTROL_PERIOD_MS) % 2000;
    bool ssr_window_allowed = s_control_tick < 1500;

    heater_set(heater && ssr_window_allowed);
    motor_set_duty(profile.motor_duty_percent);
    fan_set_duty(20);
}

esp_err_t control_service_init(void) {
    ESP_RETURN_ON_ERROR(heater_init(), TAG, "Fallo heater_init");
    ESP_RETURN_ON_ERROR(motor_init(), TAG, "Fallo motor_init");
    ESP_RETURN_ON_ERROR(fan_init(), TAG, "Fallo fan_init");
    heater_off(); motor_stop(); fan_stop();
    return ESP_OK;
}

void control_service_task(void *pvParameters) {
    SensorSample sample = {};
    TickType_t last_wake = xTaskGetTickCount();
    while (true) {
        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(CONTROL_PERIOD_MS));
        if (xQueuePeek(g_sensor_queue, &sample, 0) == pdTRUE) {
            apply_control(sample);
        } else {
            heater_off(); // Sin lectura no se permite calentar.
        }
    }
}
