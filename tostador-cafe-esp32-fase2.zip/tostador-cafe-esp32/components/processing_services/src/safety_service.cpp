#include "safety_service.h"
#include "app_config.h"
#include "app_context.h"
#include "app_events.h"
#include "heater_driver.h"
#include "motor_driver.h"
#include "fan_driver.h"
#include "esp_timer.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "SAFETY";
static SensorSample s_prev = {};
static bool s_has_prev = false;

static void force_safe_state(SafetyCode code, const SensorSample &sample) {
    heater_off();
    motor_stop();
    fan_set_duty(100);
    app_request_safe_shutdown(code);

    AlarmMessage alarm = {
        .code = code,
        .timestamp_ms = esp_timer_get_time() / 1000ULL,
        .temperature_c = sample.temperature_c
    };
    xQueueSend(g_alarm_queue, &alarm, 0);
    ESP_LOGE(TAG, "Estado seguro activado. Codigo=%u Temp=%.2f C", static_cast<unsigned>(code), sample.temperature_c);
}

static SafetyCode evaluate_sample(const SensorSample &sample) {
    RoastProfile profile = app_get_profile();

    if (!sample.thermocouple_ok) return SafetyCode::SENSOR_DISCONNECTED;
    if (sample.temperature_c < profile.min_valid_temp_c || sample.temperature_c > profile.max_temp_c) return SafetyCode::TEMP_OUT_OF_RANGE;

    if (s_has_prev) {
        float dt_s = (sample.timestamp_ms - s_prev.timestamp_ms) / 1000.0f;
        if (dt_s > 0.1f) {
            float rate = (sample.temperature_c - s_prev.temperature_c) / dt_s;
            if (rate > MAX_TEMP_RISE_C_PER_S) return SafetyCode::TEMP_RISE_TOO_FAST;
        }
    }
    return SafetyCode::OK;
}

esp_err_t safety_service_init(void) { return ESP_OK; }

void safety_service_task(void *pvParameters) {
    SensorSample sample = {};
    while (true) {
        vTaskDelay(pdMS_TO_TICKS(SAFETY_PERIOD_MS));
        if (xQueuePeek(g_sensor_queue, &sample, 0) == pdTRUE) {
            SafetyCode code = evaluate_sample(sample);
            if (code != SafetyCode::OK) {
                force_safe_state(code, sample);
            }
            s_prev = sample;
            s_has_prev = true;
        }
    }
}
