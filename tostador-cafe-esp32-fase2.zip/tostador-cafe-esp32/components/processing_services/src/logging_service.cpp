#include "logging_service.h"
#include "sd_logger.h"
#include "app_events.h"
#include "app_context.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "LOGGER";

esp_err_t logging_service_init(void) {
    esp_err_t err = sd_logger_init();
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "SD no disponible. Se continuara con salida serial.");
    }
    sd_logger_write_header();
    return ESP_OK;
}

void logging_service_task(void *pvParameters) {
    SensorSample sample;
    AlarmMessage alarm;
    while (true) {
        if (xQueueReceive(g_log_queue, &sample, pdMS_TO_TICKS(200)) == pdTRUE) {
            sd_logger_write_sample(sample, app_get_state());
        }
        if (xQueueReceive(g_alarm_queue, &alarm, 0) == pdTRUE) {
            sd_logger_write_alarm(alarm);
        }
    }
}
