#include "supervision_service.h"
#include "app_context.h"
#include "app_events.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "SUPERVISION";

esp_err_t supervision_service_init(void) { return ESP_OK; }

void supervision_service_task(void *pvParameters) {
    while (true) {
        vTaskDelay(pdMS_TO_TICKS(5000));
        ESP_LOGI(TAG, "Estado=%u Heap libre=%lu bytes SensorQ=%u LogQ=%u AlarmQ=%u",
                 static_cast<unsigned>(app_get_state()),
                 static_cast<unsigned long>(esp_get_free_heap_size()),
                 static_cast<unsigned>(uxQueueMessagesWaiting(g_sensor_queue)),
                 static_cast<unsigned>(uxQueueMessagesWaiting(g_log_queue)),
                 static_cast<unsigned>(uxQueueMessagesWaiting(g_alarm_queue)));
    }
}
