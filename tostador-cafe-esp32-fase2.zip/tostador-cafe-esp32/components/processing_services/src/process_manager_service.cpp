#include "process_manager_service.h"
#include "app_context.h"
#include "app_events.h"
#include "app_config.h"
#include "esp_timer.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "PROCESS";
static uint64_t s_roast_start_ms = 0;
static uint64_t s_cooling_start_ms = 0;

static void handle_command(UserCommand cmd) {
    ProcessState state = app_get_state();
    switch (cmd) {
        case UserCommand::START:
            if (state == ProcessState::CONFIGURATION || state == ProcessState::READY || state == ProcessState::FINISHED) {
                app_set_state(ProcessState::VALIDATION);
            }
            break;
        case UserCommand::PAUSE:
            if (state == ProcessState::ROASTING) app_set_state(ProcessState::PAUSED_SAFE);
            break;
        case UserCommand::RESUME:
            if (state == ProcessState::PAUSED_SAFE) app_set_state(ProcessState::ROASTING);
            break;
        case UserCommand::STOP:
        case UserCommand::FINISH:
            app_set_state(ProcessState::COOLING);
            s_cooling_start_ms = esp_timer_get_time() / 1000ULL;
            break;
        case UserCommand::EMERGENCY_STOP:
            app_request_safe_shutdown(SafetyCode::EMERGENCY_STOP);
            break;
        default: break;
    }
}

static void run_fsm(void) {
    ProcessState state = app_get_state();
    uint64_t now_ms = esp_timer_get_time() / 1000ULL;
    RoastProfile profile = app_get_profile();
    SensorSample sample = {};

    switch (state) {
        case ProcessState::VALIDATION:
            if (xQueuePeek(g_sensor_queue, &sample, pdMS_TO_TICKS(200)) == pdTRUE && sample.thermocouple_ok) {
                app_set_state(ProcessState::READY);
                ESP_LOGI(TAG, "Validacion correcta. Sistema listo.");
            }
            break;
        case ProcessState::READY:
            s_roast_start_ms = now_ms;
            app_set_state(ProcessState::ROASTING);
            ESP_LOGI(TAG, "Inicio de tostion");
            break;
        case ProcessState::ROASTING:
            if ((now_ms - s_roast_start_ms) >= profile.roast_time_s * 1000ULL) {
                s_cooling_start_ms = now_ms;
                app_set_state(ProcessState::COOLING);
                ESP_LOGI(TAG, "Tiempo cumplido. Enfriamiento.");
            }
            break;
        case ProcessState::COOLING:
            if (xQueuePeek(g_sensor_queue, &sample, 0) == pdTRUE) {
                bool cooled_by_temp = sample.thermocouple_ok && sample.temperature_c <= COOLING_SAFE_TEMP_C;
                bool cooled_by_time = (now_ms - s_cooling_start_ms) >= profile.cooling_time_s * 1000ULL;
                if (cooled_by_temp || cooled_by_time) app_set_state(ProcessState::FINISHED);
            }
            break;
        default: break;
    }
}

esp_err_t process_manager_service_init(void) { return ESP_OK; }

void process_manager_service_task(void *pvParameters) {
    UserCommand cmd;
    while (true) {
        if (xQueueReceive(g_command_queue, &cmd, pdMS_TO_TICKS(200)) == pdTRUE) {
            handle_command(cmd);
        }
        run_fsm();
    }
}
