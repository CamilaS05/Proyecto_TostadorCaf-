#include "configuration_service.h"
#include "app_context.h"
#include "app_config.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "CFG_SERVICE";

esp_err_t configuration_service_init(void) {
    app_set_profile(DEFAULT_PROFILE);
    ESP_LOGI(TAG, "Perfil por defecto cargado: %.1f C, %lu s", DEFAULT_PROFILE.target_temp_c, DEFAULT_PROFILE.roast_time_s);
    return ESP_OK;
}

void configuration_service_task(void *pvParameters) {
    while (true) {
        // En esta versión inicial se mantiene un perfil fijo.
        // Luego se puede actualizar desde LCD, botones, encoder o consola serial.
        vTaskDelay(pdMS_TO_TICKS(5000));
    }
}
