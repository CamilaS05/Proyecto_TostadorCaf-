#include "monitoring_service.h"
#include "app_config.h"
#include "app_events.h"
#include "app_context.h"
#include "max6675_driver.h"
#include "esp_timer.h"
#include "esp_log.h"
#include "esp_check.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "MONITOR";

esp_err_t monitoring_service_init(void) {
    ESP_RETURN_ON_ERROR(max6675_init(), TAG, "Fallo inicializando MAX6675");
    return ESP_OK;
}

void monitoring_service_task(void *pvParameters) {
    TickType_t last_wake = xTaskGetTickCount();
    SensorSample sample = {};

    while (true) {
        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(MONITORING_PERIOD_MS));
        float temp = 0.0f;
        bool ok = false;
        esp_err_t err = max6675_read_celsius(&temp, &ok);

        sample.timestamp_ms = esp_timer_get_time() / 1000ULL;
        sample.temperature_c = temp;
        sample.thermocouple_ok = (err == ESP_OK) && ok;
        sample.ambient_c = 0.0f;
        sample.humidity_percent = 0.0f;
        sample.mass_g = 0.0f;

        if (!sample.thermocouple_ok) ESP_LOGW(TAG, "Termocupla desconectada o lectura invalida");
        else ESP_LOGI(TAG, "Temperatura %.2f C", sample.temperature_c);

        if (xQueueSend(g_sensor_queue, &sample, 0) != pdTRUE) {
            SensorSample discarded;
            xQueueReceive(g_sensor_queue, &discarded, 0);
            xQueueSend(g_sensor_queue, &sample, 0);
        }
        xQueueSend(g_log_queue, &sample, pdMS_TO_TICKS(LOGGING_QUEUE_TIMEOUT_MS));
    }
}
