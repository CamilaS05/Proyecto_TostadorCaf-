/**
 * @file safety_service.h
 * @brief Servicio safety_service del tostador de café.
 */
#pragma once
#include "esp_err.h"

/** @brief Inicializa recursos internos del servicio. */
esp_err_t safety_service_init(void);
/** @brief Tarea FreeRTOS principal del servicio. */
void safety_service_task(void *pvParameters);
