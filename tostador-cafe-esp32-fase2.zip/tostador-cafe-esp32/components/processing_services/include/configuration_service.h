/**
 * @file configuration_service.h
 * @brief Servicio configuration_service del tostador de café.
 */
#pragma once
#include "esp_err.h"

/** @brief Inicializa recursos internos del servicio. */
esp_err_t configuration_service_init(void);
/** @brief Tarea FreeRTOS principal del servicio. */
void configuration_service_task(void *pvParameters);
