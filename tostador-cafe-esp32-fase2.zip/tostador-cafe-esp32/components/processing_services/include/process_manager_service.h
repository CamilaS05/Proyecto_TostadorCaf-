/**
 * @file process_manager_service.h
 * @brief Servicio process_manager_service del tostador de café.
 */
#pragma once
#include "esp_err.h"

/** @brief Inicializa recursos internos del servicio. */
esp_err_t process_manager_service_init(void);
/** @brief Tarea FreeRTOS principal del servicio. */
void process_manager_service_task(void *pvParameters);
