/**
 * @file control_service.h
 * @brief Servicio control_service del tostador de café.
 */
#pragma once
#include "esp_err.h"

/** @brief Inicializa recursos internos del servicio. */
esp_err_t control_service_init(void);
/** @brief Tarea FreeRTOS principal del servicio. */
void control_service_task(void *pvParameters);
