/**
 * @file supervision_service.h
 * @brief Servicio supervision_service del tostador de café.
 */
#pragma once
#include "esp_err.h"

/** @brief Inicializa recursos internos del servicio. */
esp_err_t supervision_service_init(void);
/** @brief Tarea FreeRTOS principal del servicio. */
void supervision_service_task(void *pvParameters);
