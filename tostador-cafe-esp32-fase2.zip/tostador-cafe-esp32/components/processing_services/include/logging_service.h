/**
 * @file logging_service.h
 * @brief Servicio logging_service del tostador de café.
 */
#pragma once
#include "esp_err.h"

/** @brief Inicializa recursos internos del servicio. */
esp_err_t logging_service_init(void);
/** @brief Tarea FreeRTOS principal del servicio. */
void logging_service_task(void *pvParameters);
