/**
 * @file monitoring_service.h
 * @brief Servicio monitoring_service del tostador de café.
 */
#pragma once
#include "esp_err.h"

/** @brief Inicializa recursos internos del servicio. */
esp_err_t monitoring_service_init(void);
/** @brief Tarea FreeRTOS principal del servicio. */
void monitoring_service_task(void *pvParameters);
