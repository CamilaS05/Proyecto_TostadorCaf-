/**
 * @file main.cpp
 * @brief Punto de entrada del tostador de café ESP32 con FreeRTOS.
 *
 * El sistema implementa un nodo IoT Level 1: el ESP32 adquiere datos,
 * procesa localmente, controla actuadores, detecta anomalías y registra
 * información sin requerir nube.
 */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_err.h"

#include "app_context.h"
#include "app_events.h"
#include "configuration_service.h"
#include "process_manager_service.h"
#include "monitoring_service.h"
#include "control_service.h"
#include "safety_service.h"
#include "logging_service.h"
#include "supervision_service.h"
#include "power_manager.h"

static const char *TAG = "MAIN";

static void create_service_tasks(void) {
    // Core 0: tareas críticas de tiempo real y seguridad.
    xTaskCreatePinnedToCore(safety_service_task, "task_safety", 4096, nullptr, 8, nullptr, 0);
    xTaskCreatePinnedToCore(monitoring_service_task, "task_monitoring", 4096, nullptr, 7, nullptr, 0);
    xTaskCreatePinnedToCore(control_service_task, "task_control", 4096, nullptr, 7, nullptr, 0);
    xTaskCreatePinnedToCore(process_manager_service_task, "task_process", 4096, nullptr, 6, nullptr, 0);

    // Core 1: servicios no críticos o de menor frecuencia.
    xTaskCreatePinnedToCore(configuration_service_task, "task_config", 3072, nullptr, 3, nullptr, 1);
    xTaskCreatePinnedToCore(logging_service_task, "task_logging", 6144, nullptr, 4, nullptr, 1);
    xTaskCreatePinnedToCore(supervision_service_task, "task_supervision", 4096, nullptr, 3, nullptr, 1);
}

extern "C" void app_main(void) {
    ESP_LOGI(TAG, "Inicializando tostador de cafe ESP32");

    if (!app_events_init()) {
        ESP_LOGE(TAG, "No fue posible crear colas/mutex FreeRTOS");
        return;
    }

    app_context_init();
    ESP_ERROR_CHECK(power_manager_init());
    ESP_ERROR_CHECK(configuration_service_init());
    ESP_ERROR_CHECK(monitoring_service_init());
    ESP_ERROR_CHECK(control_service_init());
    ESP_ERROR_CHECK(safety_service_init());
    ESP_ERROR_CHECK(logging_service_init());
    ESP_ERROR_CHECK(process_manager_service_init());
    ESP_ERROR_CHECK(supervision_service_init());

    create_service_tasks();

    ESP_LOGI(TAG, "Sistema listo. Enviar START desde commandQueue o agregar interfaz de botones/serial.");

    // Para pruebas de laboratorio: inicia automáticamente después de 3 s.
    // Si el profesor exige botón físico, comentar estas líneas y conectar UI real.
    vTaskDelay(pdMS_TO_TICKS(3000));
    UserCommand start = UserCommand::START;
    xQueueSend(g_command_queue, &start, 0);
}
